// Jason Brillante "Damdoshi"
// Pentacle Technologie 2009-2014
//
// INI io system

#include		"Ini.hpp"

void			bpt::Ini::Clear(void)
{
  datas.clear();
}

