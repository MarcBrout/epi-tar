// Jason Brillante "Damdoshi"
// Epitech 1999-2042
//
// Bibliotheque Lapin

#include		"lapin_private.h"

const t_bunny_position	*bunny_get_mouse_position(void)
{
  return (&gl_mouse);
}
